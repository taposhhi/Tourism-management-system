-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2024 at 02:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tourist spot management system`
--

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `District_code` varchar(30) NOT NULL,
  `District_name` varchar(30) DEFAULT NULL,
  `Div_code` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`District_code`, `District_name`, `Div_code`) VALUES
('BD-02', 'Thakugaon', 'BD-F'),
('BD-04', 'Nilphamari', 'BD-F'),
('BD-14', 'Rajshahi', 'BD-E'),
('BD-15', 'Sirajganj', 'BD-E'),
('BD-18', 'Meherpur', 'BD-D'),
('BD-24', 'Satkhira', 'BD-D'),
('BD-26', 'Bagerhat', 'BD-D'),
('BD-27', 'Pirojpur', 'BD-A'),
('BD-30', 'Bhola', 'BD-A'),
('BD-33', 'Netrokona', 'BD-H'),
('BD-36', 'Jamalpur', 'BD-A'),
('BD-41', 'Gazipur', 'BD-C'),
('BD-43', 'Narayanganj', 'BD-C'),
('BD-49', 'Shariatpur', 'BD-C'),
('BD-51', 'Sunamganj', 'BD-G'),
('BD-52', 'Moulvibazar', 'BD-G'),
('BD-55', 'Cumilla', 'BD-B'),
('BD-58', 'Noakhali', 'BD-B'),
('BD-59', 'Feni', 'BD-B'),
('BD-61', 'Cox\'s Bazar', 'BD-B');

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE `division` (
  `Div_code` varchar(20) NOT NULL,
  `Div_name` varchar(30) DEFAULT NULL,
  `Div_Population(million)` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`Div_code`, `Div_name`, `Div_Population(million)`) VALUES
('BD-A', 'Barishal', '9.33'),
('BD-B', 'Chattogram', '34.18'),
('BD-C', 'Dhaka', '45.64'),
('BD-D', 'Khulna', '17.81'),
('BD-E', 'Rajshahi', '20.79'),
('BD-F', 'Rangpur', '18.02'),
('BD-G', 'Sylhet', '11.42'),
('BD-H', 'Mymensingh', '12.64');

-- --------------------------------------------------------

--
-- Table structure for table `environmental_effect`
--

CREATE TABLE `environmental_effect` (
  `Place_name` varchar(200) DEFAULT NULL,
  `Environmental_Issue` varchar(200) DEFAULT NULL,
  `Severity_Level` varchar(200) DEFAULT NULL,
  `Traveler_Impact_Tips` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `environmental_effect`
--

INSERT INTO `environmental_effect` (`Place_name`, `Environmental_Issue`, `Severity_Level`, `Traveler_Impact_Tips`) VALUES
('Sundarbans Mangrove Forest', 'Deforestation and habitat loss due to illegal logging and human encroachment', 'Critical', 'Avoid disturbing wildlife, do not litter, and support eco-friendly tour operators'),
('Inani Beach', 'Plastic pollution and coral damage from unsustainable tourism', 'High', 'Carry reusable bottles, avoid plastic waste, and respect marine life by not touching corals'),
('Mainamati Ruins', 'Damage to ancient structures from too many tourists', 'Moderate', 'Do not climb on ruins, follow designated pathways, and support heritage preservation initiatives'),
('Hatiya Island', 'higher sea levels affecting locals', 'High', 'Respect local customs, avoid single-use plastics, and participate in eco-friendly tourism activities'),
('Muhuri Project', 'Water pollution and overfishing disrupting local ecosystems', 'Moderate', 'Avoid littering near water bodies, support sustainable fishing practices, and use biodegradable products'),
('Lawachara National Park', 'Deforestation and wildlife displacement due to human activities', 'High', 'Stick to designated trails, avoid loud noises, and do not feed or disturb wildlife'),
('Tanguar Haor', 'Water pollution and habitat destruction affecting migratory birds', 'High', 'avoid excessive noise near bird habitats, and use eco-friendly boats'),
('Panam City', 'Damage to historical buildings from neglect and city expansion', 'Moderate', 'Avoid damaging structures, do not litter, and support preservation projects'),
('Tista Barrage', 'Water resource mismanagement affecting agriculture and local biodiversity', 'Moderate', 'Respect local agricultural practices and avoid polluting nearby water sources'),
('Varendra Research Museum', 'None', 'Low', 'Follow museum rules and respect artifacts'),
('Bangabandhu Bridge (Jamuna Bridge)', 'None', 'Low', 'be carefull while traveling'),
('Char Kukri Mukri', 'Mangrove degradation and waste pollution from tourism', 'High', ' avoid damaging mangroves, and use eco-friendly travel options'),
('Birishiri China Clay Hills', 'Soil erosion due to unsustainable tourism practices', 'Moderate', 'Avoid causing soil disruption, stick to trails'),
('Himchari Waterfall', 'Littering and water pollution from tourists', 'High', 'Dispose of waste properly, avoid polluting the water, and stick to designated areas'),
('Saint Martin\'s Island', 'seas polluted by careless tourism', 'Critical', 'Do not touch or take corals, avoid plastic waste, and support marine conservation efforts');

-- --------------------------------------------------------

--
-- Table structure for table `famous_person`
--

CREATE TABLE `famous_person` (
  `Person_ID` int(11) NOT NULL,
  `Birthplace` varchar(10) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `Famous_for` varchar(255) DEFAULT NULL,
  `Life_period` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `famous_person`
--

INSERT INTO `famous_person` (`Person_ID`, `Birthplace`, `Name`, `Famous_for`, `Life_period`) VALUES
(1, 'BD-04', 'Abu Shaeid', 'Bangladeshi professional footballer', '1999-Present'),
(2, 'BD-33', 'Muhammad Zafar Iqbal', 'Writer', '1952-Present'),
(3, 'BD-24', 'Mustafizur Rahman', 'Bowler', '1995-Present'),
(4, 'BD-55', 'Shib Narayan Das', 'Designer of BD flag', '1946 – 2024'),
(5, 'BD-58', 'Martyr (Shaheed) Md. Ruhul Amin', 'Bir Srestho', '1935 – 1971'),
(6, 'BD-51', 'Hasan Raja', 'Wealthy landowner and poet', '1854 – 1922'),
(7, 'BD-49', 'Haji Shariatullah', 'Faraizi Movement', '1781 – 1840'),
(8, 'BD-14', 'Montazur Rahman Akbar', 'Film-maker', '1991 – 1996'),
(9, 'BD-55', 'Mohammad Nurul Huda', 'Bangladeshi poet', '1949 – 2017'),
(10, 'BD-59', 'Begum Khaleda Zia', 'Former Prime Minister of Bangladesh', '1945 – Present'),
(11, 'BD-41', 'Tajuddin Ahmad', 'First PM of Bangladesh', '1925 – 1975'),
(12, 'BD-43', 'Shakib Khan', 'Bangladeshi film actor', '1979 – Present');

-- --------------------------------------------------------

--
-- Table structure for table `famous_place`
--

CREATE TABLE `famous_place` (
  `Place_name` varchar(200) NOT NULL,
  `Funny_facts` varchar(200) NOT NULL,
  `Location` varchar(200) DEFAULT NULL,
  `District_code` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `famous_place`
--

INSERT INTO `famous_place` (`Place_name`, `Funny_facts`, `Location`, `District_code`) VALUES
('Bangabandhu Bridge (Jamuna Bridge)', 'The highway where even rivers queue up for selfies!', 'Across the Jamuna River, connecting Sirajganj and Tangail', 'BD-15'),
('Birishiri China Clay Hills', 'The colorful hills that make you wonder if nature is flexing on us!', 'Durgapur Upazila', 'BD-33'),
('Char Kukri Mukri', 'The island where even the goats enjoy sunsets!', 'Coastal Bhola, south of the district center', 'BD-30'),
('Hatiya Island', 'The island that\'s so chill, even the boats take their time!', 'Offshore from the mainland Noakhali', 'BD-58'),
('Himchari Waterfall', 'A waterfall where even the water seems to be taking a spa day!', 'Himchari, about 12 km south of Cox\'s Bazar', 'BD-61'),
('Inani Beach', 'Where you can walk endlessly and still never finish the world\'s longest beach!', 'South of Cox’s Bazar town', 'BD-61'),
('Lawachara National Park', 'Where monkeys judge your hiking skills!', 'Kamalganj Upazila', 'BD-52'),
('Mainamati Ruins', 'Ancient university vibes with bonus archaeology workout!', 'Near Kotbari, Cumilla', 'BD-55'),
('Muhuri Project', 'The dam where engineers and fish have philosophical debates!', 'Near the Indian border', 'BD-59'),
('Panam City', 'The ghost town that\'s Instagram-ready!', 'Sonargaon', 'BD-43'),
('Saint Martin\'s Island', 'The island where even the stars seem to vacation!', '9 km off the southern coast of Cox\'s Bazar, in the Bay of Bengal', 'BD-61'),
('Sundarbans Mangrove Forest', 'The ultimate neighborhood of the Bengal tigers—don\'t forget to RSVP before visiting!', 'Bordering India and the Bay of Bengal', 'BD-04'),
('Tanguar Haor', 'The floating paradise where the birds are the DJs!', 'Rural Sunamganj', 'BD-51'),
('Tista Barrage', 'The bridge where water flows smoother than your WiFi!', 'Doani, near the Indian border', 'BD-04'),
('Varendra Research Museum', 'A place where artifacts have better stories than your travel blog!', 'Rajshahi City', 'BD-14');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `Place_name` varchar(200) DEFAULT NULL,
  `Hotel_name` varchar(100) DEFAULT NULL,
  `Hotel_address` varchar(255) DEFAULT NULL,
  `Hotel_contact` varchar(50) NOT NULL,
  `Hotel_rating` decimal(3,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`Place_name`, `Hotel_name`, `Hotel_address`, `Hotel_contact`, `Hotel_rating`) VALUES
('Panam City', 'Sonargaon Royal Resort', 'Khashnogor Dighirpar, Sonargaon, Narayanganj, Bangladesh', '+88 01709371682', 4.5),
('Panam City', 'Pan Pacific Sonargaon Dhaka', '107 Kazi Nazrul Islam Avenue, Dhaka, Bangladesh', '+880 2 912 8000', 4.0),
('Lawachara National Park', 'Grand Sultan Tea Resort & Golf', 'Rajghat, Sreemangal, Sylhet, Bangladesh', '+880 821 630460', 4.5),
('Lawachara National Park', 'Paragon Hotel & Resort', 'Raghunandan, Sreemangal, Bangladesh', '+880 821 635910', 3.5),
('Mainamati Ruins', 'Hotel Nurjahan International', 'Near Comilla Cantonment', '+880-1711-234567', 4.0),
('Mainamati Ruins', 'Comilla View Hotel', 'Kandirpar, Comilla', '+880-817-4567', 3.8),
('Sundarbans Mangrove Forest', 'Hotel City Inn', 'Between Sonadanga bus stand and Shivbari junction, Khulna', '+8801766-990725', 4.0),
('Sundarbans Mangrove Forest', 'Mangrove Haven Resort', 'Near Mongla, 8 km from Mongla Port, across Laudove Ferry', '+8801775011208', 4.0),
('Saint Martin\'s Island', 'Sunset Serenity Resort', 'Western shore of Saint Martin\'s Island', '+8801781813360', 4.4),
('Hatiya Island', 'Hotel Valentino', 'Main Road, Maijdee, Noakhali.', '+8801795855555', 4.1),
('Hatiya Island', 'Sea Pearl Beach Resort & Spa', 'Jaliapalong, Inani, Ukhia, Cox’s Bazar - 4750, Bangladesh', '+8801844016120', 4.5),
('Himchari Waterfall', 'Bay Hills Hotel', 'Cox\'s Bazar Marine Dr, Himchori 4700', '+8801877715333', 4.6),
('Inani Beach', 'DERA Resort & Spa', 'Near Inani Beach, Cox’s Bazar, Bangladesh', '+8801896001112', 4.3),
('Birishiri China Clay Hills', 'YMCA Guest House', 'Birisiri Bhuligaon Rd, Durgapur 2420', '+8801966980087', 4.1),
('Saint Martin\'s Island', 'The Atlantic Resort', 'Near Saint Martin\'s Bazaar', '+8801968145221', 3.8),
('Saint Martin\'s Island', 'Santiniketan Beach Resort', 'West Beach, Saint Martin\'s Island', '+8801988927232', 4.5);

-- --------------------------------------------------------

--
-- Table structure for table `local_culture`
--

CREATE TABLE `local_culture` (
  `District_code` varchar(255) DEFAULT NULL,
  `Cultural_Highlights` varchar(255) DEFAULT NULL,
  `Local_Famous_Food` varchar(255) DEFAULT NULL,
  `Language` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `local_culture`
--

INSERT INTO `local_culture` (`District_code`, `Cultural_Highlights`, `Local_Famous_Food`, `Language`) VALUES
('BD-61', 'Cox’s Bazar’s beach culture', 'Fresh seafood', 'Chittagonian, Bengali'),
('BD-55', 'Comilla’s heritage sites, and folk traditions like the Baul music', 'Roshmalai', 'Bengali'),
('BD-58', 'Cultural diversity and traditions of the Noakhali region, with local fairs and festivals', 'Kolmi-shaak with daal', 'Bengali'),
('BD-59', 'Traditional fishing villages, and the Feni Mango festival', 'Khondoler misti', 'Bengali'),
('BD-49', 'Rich folk culture, including the traditional dance forms', 'Shorshe Ilish', 'Bengali'),
('BD-02', 'Thakurgaon’s agricultural traditions and fairs', 'Suryapuri Mango', 'Bengali'),
('BD-04', 'Nilphamari’s agricultural fairs and folk music traditions', 'Domar Sandesh', 'Bengali'),
('BD-14', 'Rajshahi’s silk industry and mango festivals', 'Rajshahi Mango', 'Bengali'),
('BD-15', 'Sirajganj’s rural culture and traditional boat festivals', 'Freshwater fish', 'Bengali'),
('BD-30', 'Bhola’s riverside culture and seasonal fairs', 'Buffalo curd', 'Bengali'),
('BD-33', 'Netrokona’s rural festivals, including the traditional Bhatiali song performance', 'Balish Misht', 'Bengali'),
('BD-27', 'Pirojpur’s boat culture and river-based festivals', 'Guava', 'Bengali'),
('BD-36', 'Jamalpur’s agricultural fairs and cultural heritage', 'Menda', 'Bengali');

-- --------------------------------------------------------

--
-- Table structure for table `photographer`
--

CREATE TABLE `photographer` (
  `Photographer_ID` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Contact_Number` varchar(15) DEFAULT NULL,
  `Ratings` double(2,1) DEFAULT NULL,
  `Availability_Status` varchar(50) DEFAULT NULL,
  `Place_Association` varchar(100) DEFAULT NULL,
  `Hourly_Rate` int(10) DEFAULT NULL,
  `Equipment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `photographer`
--

INSERT INTO `photographer` (`Photographer_ID`, `Name`, `Contact_Number`, `Ratings`, `Availability_Status`, `Place_Association`, `Hourly_Rate`, `Equipment`) VALUES
(1, 'Ayan Chowdhury', '+8801712345678', 4.8, 'Available', 'Sundarbans Mangrove Forest', 1500, 'DSLR, Drone, Telephoto Lens'),
(2, 'Nusrat Jahan', '+8801919876543', 4.6, 'Booked', 'Saint Martin\'s Island', 2000, 'DSLR, Wide-Angle Lens'),
(3, 'Kamrul Hasan', '+8801612345678', 4.7, 'On Leave', 'Panam City', 1200, 'Mirrorless Camera, Drone'),
(4, 'Farzana Rahman', '+8801711122233', 4.5, 'Available', 'Char Kukri Mukri', 1300, 'DSLR, Macro Lens'),
(5, 'Tanvir Alam', '+8801998765432', 4.9, 'Available', 'Tanguar Haor', 1800, 'DSLR, Drone, Waterproof Gear'),
(6, 'Rafiq Ahmed', '+8801881122233', 4.4, 'Booked', 'Birishiri China Clay Hills', 1100, 'DSLR, Standard Lens'),
(7, 'Mehedi Hassan', '+8801722334455', 4.7, 'Available', 'Mainamati Ruins', 1400, 'DSLR, Drone, Tripod');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `Place_name` varchar(200) DEFAULT NULL,
  `Restaurant_name` varchar(100) DEFAULT NULL,
  `Restaurant_address` varchar(255) DEFAULT NULL,
  `Restaurant_contact` varchar(50) NOT NULL,
  `Restaurant_rating` decimal(3,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`Place_name`, `Restaurant_name`, `Restaurant_address`, `Restaurant_contact`, `Restaurant_rating`) VALUES
('Saint Martin\'s Island', 'Sea Find Restaurant & Resort', 'Saint Martin', '+8801701292821', 4.4),
('Mainamati Ruins', 'Mainamati Highway Restaurant', 'Nishchintapur, Dhaka-Chittagong Highway, Cumilla 3500', '+8801745689181', 3.4),
('Lawachara National Park', 'Asia Eco Cafe & Restaurant', 'Bhanugach Rd, Sreemangal 3210', '+8801760865588', 3.9),
('Tanguar Haor', 'Hesel Restaurant', 'Sunamganj 3100', '+8801777990888', 5.0),
('Himchari Waterfall', 'Himchari Tania Restaurant', 'Himchari Ramu, Cox\'s Bazar', '+8801815763898', 4.5),
('Lawachara National Park', 'Oronno Bilash Restaurant', 'Bhanugach Rd, 3210', '+8801819314335', 4.2),
('Hatiya Island', 'Mid Night Beach Cafe', 'Near Himchari, Marine Drive Road, 4730', '+8801832822183', 4.0),
('Himchari Waterfall', 'Sea Food Cafe', 'Himchari Boro Jhorna, Ramu, Cox\'s Bazar', '+8801851318788', 4.2),
('Saint Martin\'s Island', 'Martin Full Restaurant', 'Saint Martin\'s Island Ferry Service Road', '+8801884032905', 4.2),
('Panam City', 'Panam Food Park', 'Road, Sonargaon', '+8801913074413', 4.2),
('Panam City', 'Daruchini Restaurant & Misti Ghar', 'Sonargaon', '+8801922043533', 3.7),
('Inani Beach', 'Coral Point Restaurant', 'Cox\'s Bazar-Teknaf Marine Dr', '+8801952227740', 3.6),
('Mainamati Ruins', 'Amania Hotel & Restaurant', 'Cumilla 3500', '+8808164428', 3.7),
('Tanguar Haor', 'Rose Garden Restaurant', 'Old Bus Stand, Sunamganj', '+88087162744', 3.8);

-- --------------------------------------------------------

--
-- Table structure for table `suitable_season`
--

CREATE TABLE `suitable_season` (
  `Place_name` varchar(150) DEFAULT NULL,
  `best_season` varchar(200) DEFAULT NULL,
  `season_months` varchar(100) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `activities_possible` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suitable_season`
--

INSERT INTO `suitable_season` (`Place_name`, `best_season`, `season_months`, `reason`, `activities_possible`) VALUES
('Sundarbans Mangrove Forest', 'Dry Season', 'November - April', 'The dry season offers the best chance to explore the forest without heavy rain, and it\'s easier to s', 'Wildlife watching, boat tours'),
('Inani Beach', 'Dry Season', 'November - April', 'The dry season provides perfect weather for enjoying beach activities with clear skies and warm temp', 'Swimming, sunbathing, beach walks'),
('Mainamati Ruins', 'Dry Season', 'November - March', 'The dry season is perfect for exploring the ruins, with mild weather and no rain to disrupt sightsee', 'Archaeological exploration, photography'),
('Hatiya Island', 'Dry Season', 'November - March', 'The dry season ensures calm seas and clear skies, making it ideal for a peaceful island escape.', 'Relaxing, beach activities, photography'),
('Muhuri Project', 'Dry Season', 'November - April', 'The dry season offers clear skies and calm weather, perfect for outdoor activities like fishing and ', 'Fishing, photography, birdwatching'),
('Lawachara National Park', 'Dry Season', 'November - March', 'This period offers dry and pleasant weather, perfect for trekking and spotting wildlife in the park.', 'Hiking, wildlife watching'),
('Tanguar Haor', 'Winter Season', 'December - February', 'The winter months are ideal for birdwatching, as migratory birds flock to the haor during this time.', 'Birdwatching, boat tours'),
('Panam City', 'Dry Season', 'January - April', 'The dry season is the best time to explore Panam City’s ancient ruins without the rain obstructing v', 'Exploring ruins, photography'),
('Tista Barrage', 'Any Time', 'All Year', 'You can visit the barrage any time of the year as it remains accessible and scenic throughout the se', 'Photography, sightseeing'),
('Varendra Research Museum', 'Any Time', 'All Year', 'The museum is open year-round and offers a chance to learn about the region’s history and culture in', 'Exploring artifacts, cultural visits'),
('Bangabandhu Bridge (Jamuna Bridge)', 'Any Time', 'All Year', 'The Jamuna Bridge can be visited at any time of year, with comfortable weather and spectacular views', 'Photography, sightseeing'),
('Char Kukri Mukri', 'Dry Season', 'November - April', 'The dry season offers easy access to the island and the best chance for observing wildlife and enjoy', 'Wildlife watching, boat tours'),
('Birishiri China Clay Hills', 'Dry Season', 'November - April', 'The dry season offers pleasant weather and clear views, perfect for capturing the colorful hills and', 'Photography, sightseeing'),
('Himchari Waterfall', 'Rainy Season', 'June - September', 'The rainy season brings a fuller and more spectacular waterfall, making it the best time to experien', 'Waterfall viewing, photography'),
('Himchari Waterfall', 'Dry Season', 'November - March', 'In the dry season, the waterfall is smaller, but the peaceful surroundings make it a great spot for ', 'Waterfall viewing, photography'),
('Saint Martin\'s Island', 'Dry Season', 'December - April', 'The dry season offers mild weather, calm seas, and sunny skies, making it ideal for exploring the is', 'Beach activities, exploring');

-- --------------------------------------------------------

--
-- Table structure for table `tour_guide`
--

CREATE TABLE `tour_guide` (
  `Guide_ID` int(11) NOT NULL,
  `Place_name` varchar(100) DEFAULT NULL,
  `Guide_name` varchar(100) NOT NULL,
  `Contact_number` varchar(15) NOT NULL,
  `Specialization` varchar(100) DEFAULT NULL,
  `Ratings` double(2,1) DEFAULT NULL,
  `Availability_status` varchar(50) DEFAULT NULL CHECK (`Availability_status` in ('Available','Booked','On Leave')),
  `Hourly_rate` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tour_guide`
--

INSERT INTO `tour_guide` (`Guide_ID`, `Place_name`, `Guide_name`, `Contact_number`, `Specialization`, `Ratings`, `Availability_status`, `Hourly_rate`) VALUES
(1, 'Sundarbans Mangrove Forest', 'Rajib Ahmed', '+8801723456789', 'Wildlife Tours and Boating', 4.8, 'Available', 150),
(2, 'Saint Martin\'s Island', 'Mehnaz Akter', '+8801945678901', 'Marine and Beach Activities', 4.7, 'Booked', 200),
(3, 'Panam City', 'Tariq Hossain', '+8801887654321', 'Historical Sites and Photography', 4.5, 'Available', 125),
(4, 'Tanguar Haor', 'Hasan Kabir', '+8801623456789', 'Bird Watching and Local Ecology', 4.9, 'On Leave', 180),
(5, 'Birishiri China Clay Hills', 'Shirin Akter', '+8801934567890', 'Nature Exploration and Local Culture', 4.6, 'Available', 100),
(6, 'Mainamati Ruins', 'Anwar Hossain', '+8801712345678', 'Archaeological and Historical Tours', 4.4, 'Booked', 140),
(7, 'Char Kukri Mukri', 'Sadia Parveen', '+8801555678902', 'Mangrove and Coastal Ecology', 4.7, 'Available', 160);

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `Place_name` varchar(200) DEFAULT NULL,
  `Annual_visitor(million)` double(3,1) DEFAULT NULL,
  `Ratings` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`Place_name`, `Annual_visitor(million)`, `Ratings`) VALUES
('Sundarbans Mangrove Forest', 3.7, '4.7'),
('Char Kukri Mukri', 1.9, '4.0'),
('Saint Martin\'s Island', 1.4, '4.8'),
('Panam City', 1.2, '4.3'),
('Tanguar Haor', 0.2, '4.6'),
('Birishiri China Clay Hills', 1.0, '4.0'),
('Mainamati Ruins', 3.2, '4.5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`District_code`),
  ADD KEY `Div_code` (`Div_code`);

--
-- Indexes for table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`Div_code`);

--
-- Indexes for table `environmental_effect`
--
ALTER TABLE `environmental_effect`
  ADD KEY `Place_name` (`Place_name`);

--
-- Indexes for table `famous_person`
--
ALTER TABLE `famous_person`
  ADD PRIMARY KEY (`Person_ID`),
  ADD KEY `Birthplace` (`Birthplace`);

--
-- Indexes for table `famous_place`
--
ALTER TABLE `famous_place`
  ADD PRIMARY KEY (`Place_name`),
  ADD KEY `District_code` (`District_code`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`Hotel_contact`),
  ADD KEY `Place_name` (`Place_name`);

--
-- Indexes for table `local_culture`
--
ALTER TABLE `local_culture`
  ADD KEY `District_code` (`District_code`);

--
-- Indexes for table `photographer`
--
ALTER TABLE `photographer`
  ADD PRIMARY KEY (`Photographer_ID`),
  ADD KEY `Place_Association` (`Place_Association`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`Restaurant_contact`),
  ADD KEY `Place_name` (`Place_name`);

--
-- Indexes for table `suitable_season`
--
ALTER TABLE `suitable_season`
  ADD KEY `Place_name` (`Place_name`);

--
-- Indexes for table `tour_guide`
--
ALTER TABLE `tour_guide`
  ADD PRIMARY KEY (`Guide_ID`),
  ADD KEY `Place_name` (`Place_name`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD KEY `Place_name` (`Place_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `famous_person`
--
ALTER TABLE `famous_person`
  MODIFY `Person_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `photographer`
--
ALTER TABLE `photographer`
  MODIFY `Photographer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tour_guide`
--
ALTER TABLE `tour_guide`
  MODIFY `Guide_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `district`
--
ALTER TABLE `district`
  ADD CONSTRAINT `district_ibfk_1` FOREIGN KEY (`Div_code`) REFERENCES `division` (`Div_code`);

--
-- Constraints for table `environmental_effect`
--
ALTER TABLE `environmental_effect`
  ADD CONSTRAINT `environmental_effect_ibfk_1` FOREIGN KEY (`Place_name`) REFERENCES `famous_place` (`Place_name`);

--
-- Constraints for table `famous_person`
--
ALTER TABLE `famous_person`
  ADD CONSTRAINT `famous_person_ibfk_1` FOREIGN KEY (`Birthplace`) REFERENCES `district` (`District_code`);

--
-- Constraints for table `famous_place`
--
ALTER TABLE `famous_place`
  ADD CONSTRAINT `famous_place_ibfk_1` FOREIGN KEY (`District_code`) REFERENCES `district` (`District_code`);

--
-- Constraints for table `hotel`
--
ALTER TABLE `hotel`
  ADD CONSTRAINT `hotel_ibfk_1` FOREIGN KEY (`Place_name`) REFERENCES `famous_place` (`Place_name`);

--
-- Constraints for table `local_culture`
--
ALTER TABLE `local_culture`
  ADD CONSTRAINT `local_culture_ibfk_1` FOREIGN KEY (`District_code`) REFERENCES `district` (`District_code`);

--
-- Constraints for table `photographer`
--
ALTER TABLE `photographer`
  ADD CONSTRAINT `photographer_ibfk_1` FOREIGN KEY (`Place_Association`) REFERENCES `visitors` (`Place_name`);

--
-- Constraints for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD CONSTRAINT `restaurant_ibfk_1` FOREIGN KEY (`Place_name`) REFERENCES `famous_place` (`Place_name`);

--
-- Constraints for table `suitable_season`
--
ALTER TABLE `suitable_season`
  ADD CONSTRAINT `suitable_season_ibfk_1` FOREIGN KEY (`Place_name`) REFERENCES `famous_place` (`Place_name`);

--
-- Constraints for table `tour_guide`
--
ALTER TABLE `tour_guide`
  ADD CONSTRAINT `tour_guide_ibfk_1` FOREIGN KEY (`Place_name`) REFERENCES `visitors` (`Place_name`);

--
-- Constraints for table `visitors`
--
ALTER TABLE `visitors`
  ADD CONSTRAINT `visitors_ibfk_1` FOREIGN KEY (`Place_name`) REFERENCES `famous_place` (`Place_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
